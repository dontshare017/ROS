#!/usr/bin/env sh

# Env vars we want access to in the shell tools