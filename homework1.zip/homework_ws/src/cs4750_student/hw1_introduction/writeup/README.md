# Project 1: Introduction [![tests](../../../badges/submit-proj1/pipeline.svg)](../../../pipelines/submit-proj1/latest)

1. A node is an executable files that is able to communicate information with other files (nodes) when it runs. A lot of nodes are connected with each other in a graph and exchange information with one another through topics, which are basically like hubs or transfer stations of messages. Nodes who want to deliver information to other nodes are called publishers -- as the name suggests, these nodes publish information that are sent to the topic, and subscriber nodes -- nodes who wish to receive information / data relevant to the topic -- retrieve information from the topic by subcribing to it.

2. The launch file contains information about multiple nodes and brings them together to achieve some aggregate functionality.
